<?php

namespace App\Enums;

enum Condition: string {
    case IDEAL ='идеальное';
    case NORMAL = 'нормальное';
    case NEEDS_ATTENTION = 'требует внимания';
    case FOR_TABLE = 'годится чтобы подпирать стол';
}
