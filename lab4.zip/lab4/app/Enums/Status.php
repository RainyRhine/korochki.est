<?php

namespace App\Enums;

enum Status: string {
    case NEW ='Новая';
    case CONTINUES = 'Идет обучение';
    case FINISHED = 'Обучение завершено';
}
