<?php

namespace App\Enums;

enum CourseName: string {
    case OAIP ='Основы алгоритмизации и программирования';
    case OWD = 'Основы веб-дизайна';
    case OPBD = 'Основы проектирования баз данных';

}
