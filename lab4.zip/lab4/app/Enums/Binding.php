<?php

namespace App\Enums;

enum Binding: string {
    case HARD ='твердый';
    case SOFT = 'мягкий';
}
