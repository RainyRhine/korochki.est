<?php

namespace App\Enums;

enum PaymentMethod: string {
    case CASH = 'наличными';
    case TRANS = 'перевод по номеру телефона';
}
