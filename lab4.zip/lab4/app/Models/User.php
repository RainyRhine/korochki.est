<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use Notifiable;

    protected $fillable = [
        'login',
        'name',
        'surname',
        'patronimyc',
        'phone',
        'password',
        'email',
    ];

    protected $hidden = [
        'password',
    ];

    public function cards(){
        return $this->hasMany(Card::class);
    }

    public function reviews(){
        return $this->hasMany(Review::class);
    }

    public function isAdmin(){
        return $this->role === 'admin';
    }
}
