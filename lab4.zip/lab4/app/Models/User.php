<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use Notifiable;

    protected $fillable = [
        'login',
        'name',
        'surname',
        'patronimyc',
        'phone_number',
        'password',
        'email',
    ];

    protected $hidden = [
        'password',
    ];

    public function cards(){
        return $this->hasMany(Card::class);
    }

    public function isAdmin(){
        return $this->role === 'admin';
    }
}
