<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Enums\Binding;
use App\Enums\Condition;

class Card extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'bookAuthor',
        'bookName',
        'status',
        'publisher',
        'yearOfPublishing',
        'binding',
        'condition',
    ];

    protected $casts = [
        'binding' => Binding::class,
        'condition' => Condition::class
    ];

    public function user(){
        return $this->belongsTo(User::class);
    }
}
