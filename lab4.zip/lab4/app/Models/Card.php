<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Enums\PaymentMethod;
use App\Enums\Status;
use App\Enums\CourseName;

class Card extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'course_name',
        'start_date',
        'payment_method',
        'status'
    ];

    protected $casts = [
        'payment_method' => PaymentMethod::class,
        'status' => Status::class,
        'course_name' => CourseName::class
    ];

    public function user(){
        return $this->belongsTo(User::class);
    }

    public function review(){
        return $this->hasOne(Review::class);
    }
}
