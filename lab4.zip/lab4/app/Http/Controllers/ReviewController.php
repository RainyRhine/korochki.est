<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Card;

class ReviewController extends Controller
{
    public function create(Request $request, Card $card)
    {
        $request->validate([
            'rating' => 'required|integer|min:1|max:5',
            'comment' => 'nullable|string|max:1000',
        ]);

        $card->review()->create([
            'user_id' => auth()->id(),
            'rating' => $request->rating,
            'comment' => $request->comment,
        ]);

        return redirect()->route('Cards.Page')->with('success', 'Отзыв успешно добавлен!');
    }
}
