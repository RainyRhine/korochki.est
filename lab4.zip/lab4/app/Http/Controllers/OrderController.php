<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Order;
use App\Enums\PaymentMethod;
use App\Enums\OrderService;

class OrderController extends Controller
{
    public function createOrder(Request $request){
        $request->validate([
            'order_adress' => 'required|string|max:255',
            'order_phoneNumber' => 'required|regex:/^\+7\(\d{3}\)-\d{3}-\d{2}-\d{2}$/',
            'order_datetime' => 'required|after_or_equal:today',
            'anotherServiceCheckbox' => 'nulluble|boolean',
            'order_services' => 'required_unless:anotherServiceCheckbox,on|string|nullable',
            'order_anotherService' => 'required_if:anotherServiceCheckbox,on|string|max:255|nullable',
            'order_paymentMethod' => 'required',
        ]);

        $dateTime = \Carbon\Carbon::parse($request->order_datetime)->format('Y-m-d H:i:s');

        try {
            $order = Order::create([
                'user_id' => Auth::id(),
                'adress' => $request->order_adress,
                'dateTime' => $dateTime,
                'service' => (string)$request->order_services ?? null,
                'another_service' => $request->order_services ?? null,
                'phone_number' => $request->order_phoneNumber,
                'payment_method' => $request->order_paymentMethod,

            ]);
        } catch(\Exception $ex) {
            dd('Errore: ' .$ex->getMessage());
        }

        return redirect()->route('Orders.Page');
    }
}
