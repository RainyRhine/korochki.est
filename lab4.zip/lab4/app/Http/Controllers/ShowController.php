<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Models\Card;
use App\Models\User;

class ShowController extends Controller
{
    public function showMainPage(){
        return view('Main');
    }

    public function showRegPage(){
        return view('Registration');
    }

    public function showAuthPage(){
        return view('Auth');
    }

    public function showCardFormPage(){
        $user = Auth::user();

        $column = DB::select("SHOW COLUMNS FROM cards WHERE Field = 'status'");
        $enum = $column[0]->Type;

        preg_match("/^enum\('(.*)'\)$/", $enum, $matches);
        $statuses = explode("','", $matches[1]);

        return view('CardsForm', compact('user', 'statuses'));
    }

    public function showCardShowPage(){
        $cards = Auth::user()->cards()
            ->whereIn('is_deleted', ['на рассмотрении', 'активно'])
            ->get();

        $deletedCards = Auth::user()->cards()
            ->where('is_deleted', 'удалено')
            ->get();

        return view('Cards', compact('cards', 'deletedCards'));
    }

    public function showProfilePage(){
        return view('Profile');
    }

    public function showAdminPage(){
        $users = User::with('cards')->get();

        return view('AdminPanel', compact('users'));
    }
}
