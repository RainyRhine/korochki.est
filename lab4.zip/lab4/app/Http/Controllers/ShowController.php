<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Models\Card;
use App\Models\User;

class ShowController extends Controller
{
    public function showMainPage(){
        return view('Main');
    }

    public function showRegPage(){
        return view('Registration');
    }

    public function showAuthPage(){
        return view('Auth');
    }

    public function showCardFormPage(){
        $user = Auth::user();

        $column = DB::select("SHOW COLUMNS FROM cards WHERE Field = 'status'");
        $enum = $column[0]->Type;

        preg_match("/^enum\('(.*)'\)$/", $enum, $matches);
        $statuses = explode("','", $matches[1]);

        return view('CardsForm', compact('user', 'statuses'));
    }

    public function showCardShowPage(){
        $cards = Auth::user()->cards;

        return view('Cards', compact('cards'));
    }

    public function showReviewPage(Card $card)
    {

        return view('Review', compact('card'));
    }

    public function showProfilePage(){
        return view('Profile');
    }

    public function showAdminPage(Request $request){
        // Фильтр по статусу (опционально)
        $status = $request->input('status');
        
        // Достаём пользователей с их карточками
        $users = User::with(['cards' => function($query) use ($status) {
            if ($status) {
                $query->where('status', $status); // enum хранится как поле, не как связь
            }
        }])->paginate(10); // 10 пользователей на страницу
    
        return view('AdminPanel', compact('users', 'status'));
    }
}
