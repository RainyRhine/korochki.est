<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use App\Models\User;

class AuthController extends Controller
{
    public function registrate(Request $request){
        $request->validate([
            'reg_login' => 'required|string|min:6|max:255|regex:/^[A-Za-z0-9 ]+$/u',
            'reg_password' => 'required|string|min:8|confirmed',
            'reg_FIO' => 'required|string|max:255|regex:/^[А-Яа-яЁё ]+$/u',
            'reg_phoneNumber' => 'required|regex:/^8\(\d{3}\)\d{3}-\d{2}-\d{2}$/',
            'reg_email' => 'required|email|max:255',
        ]);
        
        $FIO = preg_split('/\s+/u', trim($request->reg_FIO));

        try {
            $user = User::create([
                'login' => $request->reg_login,
                'name' => $FIO[0],
                'surname' => $FIO[1] ?? null,
                'patronimyc' => $FIO[2] ?? null,
                'phone' => $request->reg_phoneNumber,
                'password' => Hash::make($request->reg_password),
                'email' => $request->reg_email,
            ]);
        } catch (\Exception $ex) {
            dd('Errore: ' .$ex->getMessage());
        }

        Auth::login($user);

        return redirect()->intended('/');
    }

    public function authorise(Request $request){
        $request->validate([
            'auth_login' => 'required|string',
            'auth_password' => 'required|string',
        ]);

        $user = User::where('login', $request->auth_login)->first();
        if ($user && Hash::check($request->auth_password, $user->password)) {
            Auth::login($user);
            return redirect()->intended('/');
        }
        return back()->withErrors(['login_error' => 'Неверный логин или пароль']);
    }

    public function delete(Request $request){
        $user = Auth::user();

        Auth::logout();

        $user->delete();

        return redirect('/')->with('success', 'Аккаунт был успешно удален');
    }
}
