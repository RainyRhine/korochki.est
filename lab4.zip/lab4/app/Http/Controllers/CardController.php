<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Card;

class CardController extends Controller
{
    public function createCard(Request $request){
        $request->validate([
            'card_author' => 'required|max:255',
            'card_name' => 'required|max:255',
            'card_status' => 'required',
            'card_publisher' => 'max:255',
            'card_yearOfPublishing' => 'max:255',
        ]);

        try {
            $card = Card::create([
                'user_id' => Auth::id(),
                'bookAuthor' => $request->card_author,
                'bookName' => $request->card_name,
                'status' => $request->card_status,
                'publisher' => $request->card_publisher ?? null,
                'yearOfPublishing' => $request->card_yearOfPublishing ?? null,
                'binding' => $request->card_binding ?? null,
                'condition' => $request->card_condition ?? null,

            ]);
        } catch(\Exception $ex) {
            dd('Errore: ' .$ex->getMessage());
        }

        return redirect()->route('Cards.Page');
    }

    public function deleteCard(Request $request){
        $card = Card::find($request->id);

        $card->is_deleted = 'удалено';
        $card->save();

        return redirect()->back()->with('success', 'Карточка успешно удалена. Все удаленные карточки отправляются в архив');
    }

    public function acceptCard(Request $request){
        $card = Card::find($request->id);

        $card->is_deleted = 'активно';
        $card->save();

        return redirect()->back()->with('success', 'Карточка успешно принята');
    }

    public function declineCard(Request $request){
        $card = Card::find($request->id);

        $card->is_deleted = 'отклонено';
        $card->save();

        return redirect()->back()->with('success', 'Карточка успешно отклонена');
    }
}
