<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Card;

class CardController extends Controller
{
    public function createCard(Request $request){

        $request->validate([
            'card_course_name' => 'required',
            'card_start_date' => 'required',
            'card_payment_method' => 'required'
        ]);

        try {
            $card = Card::create([
                'user_id' => Auth::id(),
                'course_name' => $request->card_course_name,
                'start_date' => $request->card_start_date,
                'payment_method' => $request->card_payment_method
            ]);
        } catch(\Exception $ex) {
            dd('Errore: ' .$ex->getMessage());
        }

        return redirect()->route('Cards.Page');
    }

    public function acceptCard(Request $request){
        $card = Card::find($request->id);

        $card->status = 'Идет обучение';
        $card->save();

        return redirect()->back()->with('success', 'Карточка успешно принята');
    }

    public function declineCard(Request $request){
        $card = Card::find($request->id);

        $card->status = 'Обучение завершено';
        $card->save();

        return redirect()->back()->with('success', 'Карточка успешно отклонена');
    }
}
