<x-layout>

<div class="authorisation">
    <h3>Регистрация</h3>
    <form action="{{ route('Auth.Method') }}" method="post">
        @csrf
        <div class="authorisation-block">
            <label for="auth_login">Логин</label>
            <div>
                <input type="text" placeholder="login" name="auth_login" value="{{ old('auth_login') }}" required>
                @error('auth_login')
                    <div class="text-danger">{{ $message }}</div>
                @enderror
            </div>
        </div>

        <div class="authorisation-block">
            <label for="auth_password">Пароль</label>
            <div>
                <input type="password" placeholder="Минимум 6 символов" name="auth_password" required>
                @error('auth_password')
                    <div class="text-danger">{{ $message }}</div>
                @enderror
            </div>
        </div>

        <button type="submit">Войти</button>
    </form>

    <a href="{{ route('Reg.Page') }}">Еще нет аккаунта? Зарегистрироваться</a>
</div>

</x-layout>