<x-layout>
    <div class="container mx-auto p-4">

        {{-- Flash-сообщения --}}
        @if(session('success'))
            <div class="alert alert-success bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4">
                {{ session('success') }}
            </div>
        @endif

        @if(session('error'))
            <div class="alert alert-danger bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4">
                {{ session('error') }}
            </div>
        @endif

        {{-- Фильтр по статусу --}}
        <form method="GET" action="{{ route('Admin.Page') }}" class="mb-6 flex items-center gap-2">
            <label for="status" class="font-semibold">Фильтр по статусу:</label>
            <select name="status" id="status" class="border rounded px-2 py-1">
                <option value="">Все статусы</option>
                <option value="Новая" {{ $status == 'Новая' ? 'selected' : '' }}>Новая</option>
                <option value="Идет обучение" {{ $status == 'Идет обучение' ? 'selected' : '' }}>Идет обучение</option>
                <option value="Обучение завершено" {{ $status == 'Обучение завершено' ? 'selected' : '' }}>Обучение завершено</option>
            </select>
            <button type="submit" class="bg-blue-500 text-white px-3 py-1 rounded">Фильтровать</button>
        </form>

        {{-- Список пользователей и их карточек --}}
        @foreach($users as $user)
            <div class="user-block mb-6 p-4 border rounded shadow">
                <h3 class="text-lg font-bold mb-2">Пользователь: {{ $user->name }}</h3>

                @if($user->cards->isNotEmpty())
                    @foreach($user->cards as $card)
                        <div class="cardBlock mb-4 p-3 border rounded bg-gray-50">
                            <p><strong>Название курса:</strong> {{ $card->course_name->value }}</p>
                            <p><strong>Желаемая дата начала:</strong> {{ \Carbon\Carbon::parse($card->start_date)->format('d.m.Y') }}</p>
                            <p><strong>Способ оплаты:</strong> {{ $card->payment_method->value }}</p>
                            <p><strong>Статус:</strong> {{ $card->status->value }}</p>

                            @if($card->status->value === 'Новая' || $card->status->value === 'Идет обучение')
                                <div class="flex gap-2 mt-2">
                                    <form action="{{ route('Cards.Accept') }}" method="POST">
                                        @csrf
                                        <input type="hidden" name="id" value="{{ $card->id }}">
                                        <button type="submit" class="bg-green-500 text-white px-3 py-1 rounded">
                                            Одобрить начало обучение
                                        </button>
                                    </form>

                                    <form action="{{ route('Cards.Decline') }}" method="POST">
                                        @csrf
                                        <input type="hidden" name="id" value="{{ $card->id }}">
                                        <button type="submit" class="bg-red-500 text-white px-3 py-1 rounded">
                                            Отметить завершение обучения
                                        </button>
                                    </form>
                                </div>
                            @endif
                        </div>
                    @endforeach
                @else
                    <p>У пользователя пока нет активных карточек</p>
                @endif
            </div>
        @endforeach

        {{-- Пагинация --}}
        <div class="mt-4">
            {{ $users->links() }}
        </div>
    </div>

    {{-- Автоскрытие flash-сообщений через 5 секунд --}}
    <script>
        setTimeout(() => {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => alert.style.display = 'none');
        }, 5000);
    </script>
</x-layout>
