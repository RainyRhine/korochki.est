<x-layout>

@foreach($users as $user)

    <div class="user-block">
        <h3>Пользователь: {{ $user->name }}</h3>

        <div class="card-wrapper">
            <h4>На рассмотрении карточки</h4>

            @php
                $activeCards = $user->cards->whereIn('is_deleted', 'на рассмотрении');
            @endphp

            @if($activeCards->isNotEmpty())
                @foreach($activeCards as $card)
                    <div class="cardBlock">
                        <p>Автор книги: {{ $card->bookAuthor }}</p>
                        <p>Название книги: {{ $card->bookName }}</p>
                        <p>{{ $card->status }}</p>
                        <p>Издатель: {{ $card->publisher ?? 'Не указано' }}</p>
                        <p>Год издания: {{ $card->yearOfPublishing ?? 'Не указано' }}</p>
                        <p>Переплет: {{ $card->binding->value }}</p>
                        <p>Состояние книги: {{ $card->condition->value }}</p>
                        <p>Дата создания карточки: {{ $card->created_at->format('d.m.Y') }}</p>
                        <p>Статус: {{ $card->is_deleted }}</p>

                        <form action="{{ route('Cards.Accept') }}" method="POST">
                            @csrf
                            <input type="hidden" name="id" value="{{ $card->id }}">
                            <button type="submit">Одобрить карточку</button>
                        </form>
                        <form action="{{ route('Cards.Decline') }}" method="POST">
                            @csrf
                            <input type="hidden" name="id" value="{{ $card->id }}">
                            <button type="submit">Отклонить карточку</button>
                        </form>
                    </div>
                @endforeach
            @else
                <p>У пользователя пока нет активных карточек</p>
            @endif
        </div>

        <div class="card-wrapper">
            <h4>Активные карточки</h4>

            @php
                $activeCards = $user->cards->whereIn('is_deleted', 'активно');
            @endphp

            @if($activeCards->isNotEmpty())
                @foreach($activeCards as $card)
                    <div class="cardBlock">
                        <p>Автор книги: {{ $card->bookAuthor }}</p>
                        <p>Название книги: {{ $card->bookName }}</p>
                        <p>{{ $card->status }}</p>
                        <p>Издатель: {{ $card->publisher ?? 'Не указано' }}</p>
                        <p>Год издания: {{ $card->yearOfPublishing ?? 'Не указано' }}</p>
                        <p>Переплет: {{ $card->binding->value }}</p>
                        <p>Состояние книги: {{ $card->condition->value }}</p>
                        <p>Дата создания карточки: {{ $card->created_at->format('d.m.Y') }}</p>
                        <p>Статус: {{ $card->is_deleted }}</p>
                    </div>
                @endforeach
            @else
                <p>У пользователя пока нет активных карточек</p>
            @endif
        </div>

        <div class="card-archive">
            <h4>Архивные карточки</h4>

            @php
                $deletedCards = $user->cards->whereIn('is_deleted', ['удалено', 'отклонено']);
            @endphp

            @if($deletedCards->isNotEmpty())
                @foreach($deletedCards as $card)
                    <div class="cardBlock">
                        <p>Автор книги: {{ $card->bookAuthor }}</p>
                        <p>Название книги: {{ $card->bookName }}</p>
                        <p>{{ $card->status }}</p>
                        <p>Издатель: {{ $card->publisher ?? 'Не указано' }}</p>
                        <p>Год издания: {{ $card->yearOfPublishing ?? 'Не указано' }}</p>
                        <p>Переплет: {{ $card->binding->value }}</p>
                        <p>Состояние книги: {{ $card->condition->value }}</p>
                        <p>Дата создания карточки: {{ $card->created_at->format('d.m.Y') }}</p>
                        <p>Статус: {{ $card->is_deleted }}</p>
                    </div>
                @endforeach
            @else
                <p>Нет архивных карточек</p>
            @endif

        </div>

    </div>

@endforeach

</x-layout>