<x-layout>

<div class="card-wrapper">
    <h2>Все карточки</h2>
    @if($cards->isNotEmpty())
        @foreach($cards as $card)
            <div class="cardBlock">
                <p>Автор книги: {{ $card->bookAuthor }}</p>
                <p>Название книги: {{ $card->bookName }}</p>
                <p>{{ $card->status }}</p>
                <p>Издатель: {{ $card->publisher ?? 'Не указано' }}</p>
                <p>Год издания: {{ $card->yearOfPublishing ?? 'Не указано' }}</p>
                <p>Переплет: {{ $card->binding->value }}</p>
                <p>Состояние книги: {{ $card->condition->value }}</p>
                <p>Дата создания карточки: {{ $card->created_at->format('d.m.Y') }}</p>
                <p>Статус: {{ $card->is_deleted }}</p>
                <form action="{{ route('Cards.Delete') }}" method="POST">
                    @csrf
                    <input type="hidden" name="id" value="{{ $card->id }}">
                    <button type="submit">Удалить карточку</button>
                </form>
            </div>
        @endforeach
    @else
        <p>У вас пока нет созданных заявок</p>
    @endif

    <button><a href="{{ route('Card.Form.Page') }}">Создать новую заявку</a></button>
</div>

<div class="card-archive">
    <h2>Архивные карточки</h2>
    @if($deletedCards->isNotEmpty())
        @foreach($deletedCards as $card)
            <div class="cardBlock">
                <p>Автор книги: {{ $card->bookAuthor }}</p>
                <p>Название книги: {{ $card->bookName }}</p>
                <p>{{ $card->status }}</p>
                <p>Издатель: {{ $card->publisher ?? 'Не указано' }}</p>
                <p>Год издания: {{ $card->yearOfPublishing ?? 'Не указано' }}</p>
                <p>Переплет: {{ $card->binding->value }}</p>
                <p>Состояние книги: {{ $card->condition->value }}</p>
                <p>Дата создания карточки: {{ $card->created_at->format('d.m.Y') }}</p>
                <p>Статус: {{ $card->is_deleted }}</p>
            </div>
        @endforeach
    @else
        <p>У вас пока нет архивных заявок</p>
    @endif
</div>

</x-layout>