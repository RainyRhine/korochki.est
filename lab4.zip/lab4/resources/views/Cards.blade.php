<x-layout>

<div class="card-wrapper">
    <h2>Все карточки</h2>
    @if($cards->isNotEmpty())
        @foreach($cards as $card)
            <div class="cardBlock">
                <p>Название курса: {{ $card->course_name->value }}</p>
                <p>Желаемая дата начала: {{ \Carbon\Carbon::parse($card->start_date)->format('d.m.Y') }}</p>
                <p>Способ оплаты: {{ $card->payment_method->value }}</p>
                <p>Статус: {{ $card->status->value }}</p>
            </div>
            @if($card->status->value === 'Обучение завершено')
                @if($card->review)
                    <p>Ваш отзыв: {{ $card->review->rating }}/5 - {{ $card->review->comment }}</p>
                @else
                    <button><a href="{{ route('Review.Page', $card) }}">Оставить отзыв</a></button>
                @endif
            @endif
        @endforeach
    @else
        <p>У вас пока нет созданных карточек</p>
    @endif

    <button><a href="{{ route('Card.Form.Page') }}">Создать новую заявку</a></button>
</div>

</x-layout>