<x-layout>

<div class="registration">
    <h3>Регистрация</h3>
    <form action="{{ route('Reg.Method') }}" method="post">
        @csrf
        <div class="registration-block">
            <label for="reg_login">Логин</label>
            <div>
                <input type="text" placeholder="login" name="reg_login" value="{{ old('reg_login') }}" required>
                @error('reg_login')
                    <div class="text-danger">{{ $message }}</div>
                @enderror
            </div>
        </div>

        <div class="registration-block">
            <label for="reg_password">Пароль</label>
            <div>
                <input type="password" placeholder="Минимум 6 символов" name="reg_password" required>
                @error('reg_password')
                    <div class="text-danger">{{ $message }}</div>
                @enderror
            </div>
        </div>

        <div class="registration-block">
            <label for="reg_password_confirmation">Подтвердите пароль</label>
            <div>
                <input type="password" placeholder="Пароли должны совпадать" name="reg_password_confirmation" required>
                @error('reg_password_confirmation')
                    <div class="text-danger">{{ $message }}</div>
                @enderror
            </div>
        </div>

        <div class="registration-block">
            <label for="reg_FIO">ФИО</label>
            <div>
                <input type="text" placeholder="ФИО" name="reg_FIO" value="{{ old('reg_FIO') }}" required>
                @error('reg_FIO')
                    <div class="text-danger">{{ $message }}</div>
                @enderror
            </div>
        </div>

        <div class="registration-block">
            <label for="reg_phoneNumber">Телефон</label>
            <div>
                <input type="text" placeholder="8(123)456-78-90" name="reg_phoneNumber" value="{{ old('reg_phoneNumber') }}" required>
                @error('reg_phoneNumber')
                    <div class="text-danger">{{ $message }}</div>
                @enderror
            </div>
        </div>

        <div class="registration-block">
            <label for="reg_email">Электронная почта</label>
            <div>
                <input type="email" placeholder="example@example.ru" name="reg_email" value="{{ old('reg_email') }}" required>
            </div>
        </div>

        <button type="submit">Зарегистрироваться</button>
    </form>

    <a href="{{ route('Auth.Page') }}">Уже есть аккаунт? Войти</a>
</div>

</x-layout>