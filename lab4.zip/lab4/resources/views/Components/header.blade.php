<nav class="navbar">
    <ul class="navbar-menu">
        <li class="navbar-menu-item {{ request()->routeIs('Main.Page') ? 'active' : '' }}">
            <a href="{{ route('Main.Page') }}">Главная</a>
        </li>
        <li class="navbar-menu-item {{ request()->routeIs('Card.Page') ? 'active' : '' }}">
            <a href="{{ route('Card.Form.Page') }}">Создать карточку</a>
        </li>
        <li class="navbar-menu-item {{ request()->routeIs('Cards.Page') ? 'active' : '' }}">
            <a href="{{ route('Cards.Page') }}">Мои карточки</a>
        </li>

        @auth
            <li class="navbar-menu-item {{ request()->routeIs('Profile.Page') ? 'active' : '' }}">
                <a href="{{ route('Profile.Page') }}">Профиль</a>
            </li>

            @if(Auth::user() && Auth::user()->isAdmin())
                <li class="navbar-menu-item {{ request()->routeIs('Admin.Page') ? 'active' : '' }}">
                    <a href="{{ route('Admin.Page') }}">Админка</a>
                </li>
            @endif
        @else
            <li class="navbar-menu-item {{ request()->routeIs('Reg.Page') ? 'active' : '' }}">
                <a href="{{ route('Reg.Page') }}">Регистрация</a>
            </li>
            <li class="navbar-menu-item {{ request()->routeIs('Auth.Page') ? 'active' : '' }}">
                <a href="{{ route('Auth.Page') }}">Вход</a>
            </li>
        @endauth
    </ul>
</nav>