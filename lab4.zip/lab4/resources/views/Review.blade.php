<x-layout>

<h2>Оставить отзыв на курс: {{ $card->course_name->value }}</h2>

<form action="{{ route('Review.Method', $card) }}" method="POST">
    @csrf
    <label>Оценка (1-5)</label>
    <input type="number" name="rating" min="1" max="5" required>
    
    <label>Комментарий</label>
    <textarea name="comment"></textarea>
    
    <button type="submit">Отправить отзыв</button>
</form>

</x-layout>
