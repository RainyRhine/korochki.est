<x-layout>
    Главная

    <div class="slider">
        <div class="slides">
            <div class="slide"><img src="{{ asset('img/image06.jpg') }}"></div>
            <div class="slide"><img src="{{ asset('img/image07.jpg') }}"></div>
            <div class="slide"><img src="{{ asset('img/image08.webp') }}"></div>
            <div class="slide"><img src="{{ asset('img/image09.webp') }}"></div>
        </div>

        <button class="prev">&#10094;</button>
        <button class="next">&#10095;</button>
    </div>
</x-layout>

<script>
    const slides = document.querySelector('.slides');
    const slidesCount = document.querySelectorAll('.slide').length;

    const prevButton = document.querySelector('.prev');
    const nextButton = document.querySelector('.next');

    let currentIndex = 0;

    function goToSlide(index){
        if (index<0){
            index = slidesCount-1;
        } else if (index >= slidesCount){
            index = 0;
        }
        currentIndex = index;
        slides.style.transform =`translateX(${-index * 100}%)`;
    }

    prevButton.addEventListener('click', () => {
        goToSlide(currentIndex - 1);
    });

    nextButton.addEventListener('click', () => {
        goToSlide(currentIndex + 1);
    });

    goToSlide(0);

    setInterval(() => {
        goToSlide(currentIndex + 1);
    }, 3000);
</script>