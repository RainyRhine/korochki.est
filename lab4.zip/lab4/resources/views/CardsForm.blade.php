<x-layout>

<form action="{{route('Card.Form.Create.Method')}}" method="post">
    @csrf
    <div class="card-block">
        <label for="card_course_name">Название курса</label>
        <div>
            <select name="card_course_name">
                @foreach(\App\Enums\CourseName::cases() as $bind)
                    <option value="{{ $bind->value }}">{{ ucfirst($bind->value) }}</option>
                @endforeach
            </select>
            @error('card_course_name')
                <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>
    </div>

    <div class="card-block">
        <label for="card_start_date">Желаемая дата начала обучения</label>
        <div>
            <input type="date" name="card_start_date" value="{{ old('card_start_date') }}" required>
            @error('card_start_date')
                <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>
    </div>

    <div class="card-block">
        <label for="card_payment_method">Название курса</label>
        <div>
            <select name="card_payment_method">
                @foreach(\App\Enums\PaymentMethod::cases() as $bind)
                    <option value="{{ $bind->value }}">{{ ucfirst($bind->value) }}</option>
                @endforeach
            </select>
            @error('card_payment_method')
                <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>
    </div>

    <input type="submit" value="Отправить заявку">
</form>

</x-layout>