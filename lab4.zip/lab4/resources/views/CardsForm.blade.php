<x-layout>

<form action="{{route('Card.Form.Create.Method')}}" method="post">
    @csrf
    <div class="card-block">
        <label for="card_author">Автор*</label>
        <div>
            <input type="text" placeholder="Автор" name="card_author" value="{{ old('card_author') }}" required>
            @error('card_author')
                <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>
    </div>

    <div class="card-block">
        <label for="card_name">Название книги*</label>
        <div>
            <input type="text" placeholder="Название" name="card_name" value="{{ old('card_name') }}" required>
            @error('card_name')
                <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>
    </div>

    <div class="card-block">
        <label for="card_status">Статус*</label>
        <div>
            <label><input type="radio" name="card_status" value="готов поделиться" checked>Готов поделиться</label>
            <label><input type="radio" name="card_status" value="хочу в свою библиотеку">Хочу в свою библиотеку</label>
            @error('card_status')
                <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>
    </div>

    <div class="card-block">
        <label for="card_publisher">Издатель</label>
        <div>
            <input type="text" placeholder="Издатель" name="card_publisher" value="{{ old('card_publisher') }}">
            @error('card_publisher')
                <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>
    </div>

    <div class="card-block">
        <label for="card_yearOfPublishing">Год издания</label>
        <div>
            <input type="text" placeholder="Год издания" name="card_yearOfPublishing" value="{{ old('card_yearOfPublishing') }}">
            @error('card_yearOfPublishing')
                <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>
    </div>

    <div class="card-block">
        <label for="card_binding">Переплет*</label>
        <div>
            <select name="card_binding">
                @foreach(\App\Enums\binding::cases() as $bind)
                    <option value="{{ $bind->value }}">{{ ucfirst($bind->value) }}</option>
                @endforeach
            </select>
            @error('card_binding')
                <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>
    </div>

    <div class="card-block">
        <label for="card_condition">Состояние книги*</label>
        <div>
            <select name="card_condition">
                @foreach(\App\Enums\condition::cases() as $condition)
                    <option value="{{ $condition->value }}">{{ ucfirst($condition->value) }}</option>
                @endforeach
            </select>
            @error('card_condition')
                <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>
    </div>

    <input type="submit" value="Отправить заявку">
</form>

</x-layout>