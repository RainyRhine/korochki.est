<x-layout>
    
<form action="{{route('logout')}}" method="post">
    @csrf
    <button>Выйти из аккаунта</button>
</form>

<form action="{{ route('Delete.Method') }}" method="POST">
    @csrf
    @method('DELETE')

    <button type="submit">Удалить аккаунт</button>
</form>

</x-layout>