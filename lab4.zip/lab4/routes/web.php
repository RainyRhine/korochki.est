<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ShowController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\CardController;
use App\Http\Controllers\ReviewController;

Route::get('/', [ShowController::class, 'showMainPage'])->name('Main.Page');

Route::get('/registration', [ShowController::class, 'showRegPage'])->name('Reg.Page');
Route::post('/registration/registrate', [AuthController::class, 'registrate'])->name('Reg.Method');

Route::get('/authorisation', [ShowController::class, 'showAuthPage'])->name('Auth.Page');
Route::post('/authorisation/authorise', [AuthController::class, 'authorise'])->name('Auth.Method');
Route::post('/logout', function() {
    Auth::logout();
    return redirect('/');
})->name('logout')->middleware('auth');
Route::delete('/delete', [AuthController::class, 'delete'])->name('Delete.Method')->middleware('auth');;

Route::get('/card/form', [ShowController::class, 'showCardFormPage'])->name('Card.Form.Page')->middleware('auth');
Route::post('/card/form/create', [CardController::class, 'createCard'])->name('Card.Form.Create.Method');

Route::get('/card/show', [ShowController::class, 'showCardShowPage'])->name('Cards.Page')->middleware('auth');

Route::post('/card/show/accept', [CardController::class, 'acceptCard'])->name('Cards.Accept')->middleware('auth');
Route::post('/card/show/decline', [CardController::class, 'declineCard'])->name('Cards.Decline')->middleware('auth');

Route::get('/cards/{card}/review', [ShowController::class, 'showReviewPage'])->name('Review.Page')->middleware('auth');
Route::post('/cards/{card}/review', [ReviewController::class, 'create'])->name('Review.Method')->middleware('auth');

Route::get('/profile', [ShowController::class, 'showProfilePage'])->name('Profile.Page')->middleware('auth');

Route::get('/adminPanel', [ShowController::class, 'showAdminPage'])->name('Admin.Page')->middleware('admin');