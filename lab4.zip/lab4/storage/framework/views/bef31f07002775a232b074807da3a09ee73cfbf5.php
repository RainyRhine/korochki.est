<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layout','data' => []]); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

<div class="registration">
    <h3>Регистрация</h3>
    <form action="<?php echo e(route('Reg.Method')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="registration-block">
            <label for="reg_login">Логин</label>
            <div>
                <input type="text" placeholder="login" name="reg_login" value="<?php echo e(old('reg_login')); ?>" required>
                <?php $__errorArgs = ['reg_login'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="registration-block">
            <label for="reg_password">Пароль</label>
            <div>
                <input type="password" placeholder="Минимум 6 символов" name="reg_password" required>
                <?php $__errorArgs = ['reg_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="registration-block">
            <label for="reg_password_confirmation">Подтвердите пароль</label>
            <div>
                <input type="password" placeholder="Пароли должны совпадать" name="reg_password_confirmation" required>
                <?php $__errorArgs = ['reg_password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="registration-block">
            <label for="reg_FIO">ФИО</label>
            <div>
                <input type="text" placeholder="ФИО" name="reg_FIO" value="<?php echo e(old('reg_FIO')); ?>" required>
                <?php $__errorArgs = ['reg_FIO'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="registration-block">
            <label for="reg_phoneNumber">Телефон</label>
            <div>
                <input type="text" placeholder="8(123)456-78-90" name="reg_phoneNumber" value="<?php echo e(old('reg_phoneNumber')); ?>" required>
                <?php $__errorArgs = ['reg_phoneNumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="registration-block">
            <label for="reg_email">Электронная почта</label>
            <div>
                <input type="email" placeholder="example@example.ru" name="reg_email" value="<?php echo e(old('reg_email')); ?>" required>
            </div>
        </div>

        <button type="submit">Зарегистрироваться</button>
    </form>

    <a href="<?php echo e(route('Auth.Page')); ?>">Уже есть аккаунт? Войти</a>
</div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH C:\OSPanel\domains\localhost\Desyatnikova\lab4\resources\views/Registration.blade.php ENDPATH**/ ?>