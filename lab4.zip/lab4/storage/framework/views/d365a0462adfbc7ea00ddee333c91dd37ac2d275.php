<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
<title>Буквоежка</title><?php /**PATH C:\OSPanel\domains\localhost\Desyatnikova\lab3\resources\views/components/head.blade.php ENDPATH**/ ?>