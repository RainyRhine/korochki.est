<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layout','data' => []]); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

<div class="card-wrapper">
    <h2>Все карточки</h2>
    <?php if($cards->isNotEmpty()): ?>
        <?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="cardBlock">
                <p>Название курса: <?php echo e($card->course_name->value); ?></p>
                <p>Желаемая дата начала: <?php echo e(\Carbon\Carbon::parse($card->start_date)->format('d.m.Y')); ?></p>
                <p>Способ оплаты: <?php echo e($card->payment_method->value); ?></p>
                <p>Статус: <?php echo e($card->status->value); ?></p>
            </div>
            <?php if($card->status->value === 'Обучение завершено'): ?>
                <?php if($card->review): ?>
                    <p>Ваш отзыв: <?php echo e($card->review->rating); ?>/5 - <?php echo e($card->review->comment); ?></p>
                <?php else: ?>
                    <button><a href="<?php echo e(route('Review.Page', $card)); ?>">Оставить отзыв</a></button>
                <?php endif; ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <p>У вас пока нет созданных карточек</p>
    <?php endif; ?>

    <button><a href="<?php echo e(route('Card.Form.Page')); ?>">Создать новую заявку</a></button>
</div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH C:\OSPanel\domains\localhost\Desyatnikova\lab4\resources\views/Cards.blade.php ENDPATH**/ ?>