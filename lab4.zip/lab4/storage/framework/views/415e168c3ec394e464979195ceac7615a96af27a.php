<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layout','data' => []]); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

<div>
    <?php if($orders->isNotEmpty()): ?>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="orderBlock">
                <p><?php echo e($order->adress); ?></p>
                <p><?php echo e($order->date); ?></p>
                <p><?php echo e($order->service); ?></p>
                <p><?php echo e($order->phone_number); ?></p>
                <p><?php echo e($order->payment_method); ?></p>
                <p><?php echo e($order->status); ?></p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <p>У вас пока нет созданных заявок</p>
    <?php endif; ?>

    <button><a href="<?php echo e(route('Order.Form.Page')); ?>">Создать новую заявку</a></button>
</div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH D:\OSPanel\domains\localhost\Desyatnikova\lab2\resources\views/Orders.blade.php ENDPATH**/ ?>