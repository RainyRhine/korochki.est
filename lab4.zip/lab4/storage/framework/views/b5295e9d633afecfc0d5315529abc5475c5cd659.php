<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layout','data' => []]); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

<h2>Оставить отзыв на курс: <?php echo e($card->course_name->value); ?></h2>

<form action="<?php echo e(route('Review.Method', $card)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <label>Оценка (1-5)</label>
    <input type="number" name="rating" min="1" max="5" required>
    
    <label>Комментарий</label>
    <textarea name="comment"></textarea>
    
    <button type="submit">Отправить отзыв</button>
</form>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH C:\OSPanel\domains\localhost\Desyatnikova\lab4\resources\views/Review.blade.php ENDPATH**/ ?>