<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layout','data' => []]); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

<form action="<?php echo e(route('Order.Form.Create.Method')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="order-block">
        <label for="order_adress">Адрес</label>
        <div>
            <input type="text" placeholder="адрес" name="order_adress" value="<?php echo e(old('order_adress')); ?>" required>
            <?php $__errorArgs = ['order_adress'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="order-block">
        <label for="order_phoneNumber">Контактный номер</label>
        <div>
            <input type="text" placeholder="+7(123)-456-78-90" name="order_phoneNumber" value="<?php echo e(trim($user->phoneNumber)); ?>" required>
            <?php $__errorArgs = ['order_phoneNumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="order-block">
        <label for="order_datetime">Дата и время</label>
        <div>
            <input type="datetime-local"name="order_datetime" value="<?php echo e(old('order_datetime')); ?>" required>
            <?php $__errorArgs = ['order_datetime'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="order-block">
        <label for="order_services">Услуги</label>
        <div>
            <select name="order_services" id="order_services">
                <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($option); ?>"><?php echo e(ucfirst($option)); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['order_services'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="order-block">
        <input type="checkbox" id="anotherServiceCheckbox" name="anotherServiceCheckbox" onclick="toggleAnotherService(this)"><label for="anotherServiceCheckbox">Иная услуга</label>
    </div>

    <div class="order-block" id="anotherServiceBlock" style="display: none;">
        <label for="order_anotherService">Иная услуга</label>
        <div>
            <input type="text" placeholder="Опишите услугу, которая вам нужна" name="order_anotherService" value="<?php echo e(old('order_anotherService')); ?>">
            <?php $__errorArgs = ['order_anotherService'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="order-block">
        <label for="order_paymentMethod">Способ оплаты</label>
        <div>
            <select name="order_paymentMethod">
                <?php $__currentLoopData = \App\Enums\PaymentMethod::cases(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($method->value); ?>"><?php echo e(ucfirst($method->value)); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['order_paymentMethod'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <input type="submit" value="Отправить заявку">
</form>

<script>
    const anotherBlock = document.getElementById('anotherServiceBlock');
    const select = document.getElementById('order_services');

    function toggleAnotherService(checkbox){
        if(checkbox.checked){
            anotherBlock.style.display = 'block';
            select.disabled = true;
        } else {
            anotherBlock.style.display = 'none';
            select.disabled = false;
        }
    }

    toggleAnotherService();
</script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH D:\OSPanel\domains\localhost\Desyatnikova\lab2\resources\views/OrdersForm.blade.php ENDPATH**/ ?>