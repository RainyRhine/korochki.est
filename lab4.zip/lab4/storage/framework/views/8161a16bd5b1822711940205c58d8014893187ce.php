<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layout','data' => []]); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

<div class="card-wrapper">
    <h2>Все карточки</h2>
    <?php if($cards->isNotEmpty()): ?>
        <?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="cardBlock">
                <p>Автор книги: <?php echo e($card->bookAuthor); ?></p>
                <p>Название книги: <?php echo e($card->bookName); ?></p>
                <p><?php echo e($card->status); ?></p>
                <p>Издатель: <?php echo e($card->publisher ?? 'Не указано'); ?></p>
                <p>Год издания: <?php echo e($card->yearOfPublishing ?? 'Не указано'); ?></p>
                <p>Переплет: <?php echo e($card->binding->value); ?></p>
                <p>Состояние книги: <?php echo e($card->condition->value); ?></p>
                <p>Дата создания карточки: <?php echo e($card->created_at->format('d.m.Y')); ?></p>
                <p>Статус: <?php echo e($card->is_deleted); ?></p>
                <form action="<?php echo e(route('Cards.Delete')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" value="<?php echo e($card->id); ?>">
                    <button type="submit">Удалить карточку</button>
                </form>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <p>У вас пока нет созданных заявок</p>
    <?php endif; ?>

    <button><a href="<?php echo e(route('Card.Form.Page')); ?>">Создать новую заявку</a></button>
</div>

<div class="card-archive">
    <h2>Архивные карточки</h2>
    <?php if($deletedCards->isNotEmpty()): ?>
        <?php $__currentLoopData = $deletedCards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="cardBlock">
                <p>Автор книги: <?php echo e($card->bookAuthor); ?></p>
                <p>Название книги: <?php echo e($card->bookName); ?></p>
                <p><?php echo e($card->status); ?></p>
                <p>Издатель: <?php echo e($card->publisher ?? 'Не указано'); ?></p>
                <p>Год издания: <?php echo e($card->yearOfPublishing ?? 'Не указано'); ?></p>
                <p>Переплет: <?php echo e($card->binding->value); ?></p>
                <p>Состояние книги: <?php echo e($card->condition->value); ?></p>
                <p>Дата создания карточки: <?php echo e($card->created_at->format('d.m.Y')); ?></p>
                <p>Статус: <?php echo e($card->is_deleted); ?></p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <p>У вас пока нет архивных заявок</p>
    <?php endif; ?>
</div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH C:\OSPanel\domains\localhost\Desyatnikova\lab3\resources\views/Cards.blade.php ENDPATH**/ ?>