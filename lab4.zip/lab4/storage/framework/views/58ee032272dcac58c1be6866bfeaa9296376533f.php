<nav class="navbar">
    <ul class="navbar-menu">
        <li class="navbar-menu-item <?php echo e(request()->routeIs('Main.Page') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('Main.Page')); ?>">Главная</a>
        </li>
        <li class="navbar-menu-item <?php echo e(request()->routeIs('Card.Page') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('Card.Form.Page')); ?>">Создать карточку</a>
        </li>
        <li class="navbar-menu-item <?php echo e(request()->routeIs('Cards.Page') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('Cards.Page')); ?>">Мои карточки</a>
        </li>

        <?php if(auth()->guard()->check()): ?>
            <li class="navbar-menu-item <?php echo e(request()->routeIs('Profile.Page') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('Profile.Page')); ?>">Профиль</a>
            </li>

            <?php if(Auth::user() && Auth::user()->isAdmin()): ?>
                <li class="navbar-menu-item <?php echo e(request()->routeIs('Admin.Page') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('Admin.Page')); ?>">Админка</a>
                </li>
            <?php endif; ?>
        <?php else: ?>
            <li class="navbar-menu-item <?php echo e(request()->routeIs('Reg.Page') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('Reg.Page')); ?>">Регистрация</a>
            </li>
            <li class="navbar-menu-item <?php echo e(request()->routeIs('Auth.Page') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('Auth.Page')); ?>">Вход</a>
            </li>
        <?php endif; ?>
    </ul>
</nav><?php /**PATH C:\OSPanel\domains\localhost\Desyatnikova\lab3\resources\views/components/header.blade.php ENDPATH**/ ?>