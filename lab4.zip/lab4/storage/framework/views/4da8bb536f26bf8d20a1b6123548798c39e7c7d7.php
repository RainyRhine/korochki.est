<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layout','data' => []]); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="container mx-auto p-4">

        
        <?php if(session('success')): ?>
            <div class="alert alert-success bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        
        <form method="GET" action="<?php echo e(route('Admin.Page')); ?>" class="mb-6 flex items-center gap-2">
            <label for="status" class="font-semibold">Фильтр по статусу:</label>
            <select name="status" id="status" class="border rounded px-2 py-1">
                <option value="">Все статусы</option>
                <option value="Новая" <?php echo e($status == 'Новая' ? 'selected' : ''); ?>>Новая</option>
                <option value="Идет обучение" <?php echo e($status == 'Идет обучение' ? 'selected' : ''); ?>>Идет обучение</option>
                <option value="Обучение завершено" <?php echo e($status == 'Обучение завершено' ? 'selected' : ''); ?>>Обучение завершено</option>
            </select>
            <button type="submit" class="bg-blue-500 text-white px-3 py-1 rounded">Фильтровать</button>
        </form>

        
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="user-block mb-6 p-4 border rounded shadow">
                <h3 class="text-lg font-bold mb-2">Пользователь: <?php echo e($user->name); ?></h3>

                <?php if($user->cards->isNotEmpty()): ?>
                    <?php $__currentLoopData = $user->cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="cardBlock mb-4 p-3 border rounded bg-gray-50">
                            <p><strong>Название курса:</strong> <?php echo e($card->course_name->value); ?></p>
                            <p><strong>Желаемая дата начала:</strong> <?php echo e(\Carbon\Carbon::parse($card->start_date)->format('d.m.Y')); ?></p>
                            <p><strong>Способ оплаты:</strong> <?php echo e($card->payment_method->value); ?></p>
                            <p><strong>Статус:</strong> <?php echo e($card->status->value); ?></p>

                            <?php if($card->status->value === 'Новая' || $card->status->value === 'Идет обучение'): ?>
                                <div class="flex gap-2 mt-2">
                                    <form action="<?php echo e(route('Cards.Accept')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="id" value="<?php echo e($card->id); ?>">
                                        <button type="submit" class="bg-green-500 text-white px-3 py-1 rounded">
                                            Одобрить начало обучение
                                        </button>
                                    </form>

                                    <form action="<?php echo e(route('Cards.Decline')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="id" value="<?php echo e($card->id); ?>">
                                        <button type="submit" class="bg-red-500 text-white px-3 py-1 rounded">
                                            Отметить завершение обучения
                                        </button>
                                    </form>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <p>У пользователя пока нет активных карточек</p>
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
        <div class="mt-4">
            <?php echo e($users->links()); ?>

        </div>
    </div>

    
    <script>
        setTimeout(() => {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => alert.style.display = 'none');
        }, 5000);
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH C:\OSPanel\domains\localhost\Desyatnikova\lab4\resources\views/AdminPanel.blade.php ENDPATH**/ ?>