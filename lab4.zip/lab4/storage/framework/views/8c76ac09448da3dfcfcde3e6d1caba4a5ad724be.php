<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layout','data' => []]); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="user-block">
        <h3>Пользователь: <?php echo e($user->name); ?></h3>

        <div class="card-wrapper">
            <h4>На рассмотрении карточки</h4>

            <?php
                $activeCards = $user->cards->whereIn('is_deleted', 'на рассмотрении');
            ?>

            <?php if($activeCards->isNotEmpty()): ?>
                <?php $__currentLoopData = $activeCards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="cardBlock">
                        <p>Автор книги: <?php echo e($card->bookAuthor); ?></p>
                        <p>Название книги: <?php echo e($card->bookName); ?></p>
                        <p><?php echo e($card->status); ?></p>
                        <p>Издатель: <?php echo e($card->publisher ?? 'Не указано'); ?></p>
                        <p>Год издания: <?php echo e($card->yearOfPublishing ?? 'Не указано'); ?></p>
                        <p>Переплет: <?php echo e($card->binding->value); ?></p>
                        <p>Состояние книги: <?php echo e($card->condition->value); ?></p>
                        <p>Дата создания карточки: <?php echo e($card->created_at->format('d.m.Y')); ?></p>
                        <p>Статус: <?php echo e($card->is_deleted); ?></p>

                        <form action="<?php echo e(route('Cards.Accept')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($card->id); ?>">
                            <button type="submit">Одобрить карточку</button>
                        </form>
                        <form action="<?php echo e(route('Cards.Decline')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($card->id); ?>">
                            <button type="submit">Отклонить карточку</button>
                        </form>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <p>У пользователя пока нет активных карточек</p>
            <?php endif; ?>
        </div>

        <div class="card-wrapper">
            <h4>Активные карточки</h4>

            <?php
                $activeCards = $user->cards->whereIn('is_deleted', 'активно');
            ?>

            <?php if($activeCards->isNotEmpty()): ?>
                <?php $__currentLoopData = $activeCards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="cardBlock">
                        <p>Автор книги: <?php echo e($card->bookAuthor); ?></p>
                        <p>Название книги: <?php echo e($card->bookName); ?></p>
                        <p><?php echo e($card->status); ?></p>
                        <p>Издатель: <?php echo e($card->publisher ?? 'Не указано'); ?></p>
                        <p>Год издания: <?php echo e($card->yearOfPublishing ?? 'Не указано'); ?></p>
                        <p>Переплет: <?php echo e($card->binding->value); ?></p>
                        <p>Состояние книги: <?php echo e($card->condition->value); ?></p>
                        <p>Дата создания карточки: <?php echo e($card->created_at->format('d.m.Y')); ?></p>
                        <p>Статус: <?php echo e($card->is_deleted); ?></p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <p>У пользователя пока нет активных карточек</p>
            <?php endif; ?>
        </div>

        <div class="card-archive">
            <h4>Архивные карточки</h4>

            <?php
                $deletedCards = $user->cards->whereIn('is_deleted', ['удалено', 'отклонено']);
            ?>

            <?php if($deletedCards->isNotEmpty()): ?>
                <?php $__currentLoopData = $deletedCards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="cardBlock">
                        <p>Автор книги: <?php echo e($card->bookAuthor); ?></p>
                        <p>Название книги: <?php echo e($card->bookName); ?></p>
                        <p><?php echo e($card->status); ?></p>
                        <p>Издатель: <?php echo e($card->publisher ?? 'Не указано'); ?></p>
                        <p>Год издания: <?php echo e($card->yearOfPublishing ?? 'Не указано'); ?></p>
                        <p>Переплет: <?php echo e($card->binding->value); ?></p>
                        <p>Состояние книги: <?php echo e($card->condition->value); ?></p>
                        <p>Дата создания карточки: <?php echo e($card->created_at->format('d.m.Y')); ?></p>
                        <p>Статус: <?php echo e($card->is_deleted); ?></p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <p>Нет архивных карточек</p>
            <?php endif; ?>

        </div>

    </div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH C:\OSPanel\domains\localhost\Desyatnikova\lab3\resources\views/AdminPanel.blade.php ENDPATH**/ ?>