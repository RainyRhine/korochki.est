<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layout','data' => []]); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    Главная

    <div class="slider">
        <div class="slides">
            <div class="slide"><img src="<?php echo e(asset('img/image06.jpg')); ?>"></div>
            <div class="slide"><img src="<?php echo e(asset('img/image07.jpg')); ?>"></div>
            <div class="slide"><img src="<?php echo e(asset('img/image08.webp')); ?>"></div>
            <div class="slide"><img src="<?php echo e(asset('img/image09.webp')); ?>"></div>
            <div class="slide"><img src="<?php echo e(asset('img/image10.webp')); ?>"></div>
            <div class="slide"><img src="<?php echo e(asset('img/image11.jpg')); ?>"></div>
            <div class="slide"><img src="<?php echo e(asset('img/image12.webp')); ?>"></div>
            <div class="slide"><img src="<?php echo e(asset('img/image13.webp')); ?>"></div>
        </div>

        <button class="prev">&#10094;</button>
        <button class="next">&#10095;</button>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

<script>
    const slides = document.querySelector('.slides');
    const slidesCount = document.querySelectorAll('.slide').length;

    const prevButton = document.querySelector('.prev');
    const nextButton = document.querySelector('.next');

    let currentIndex = 0;

    function goToSlide(index){
        if (index<0){
            index = slidesCount-1;
        } else if (index >= slidesCount){
            index = 0;
        }
        currentIndex = index;
        slides.style.transform =`translateX(${-index * 100}%)`;
    }

    prevButton.addEventListener('click', () => {
        goToSlide(currentIndex - 1);
    });

    nextButton.addEventListener('click', () => {
        goToSlide(currentIndex + 1);
    });

    goToSlide(0);
</script><?php /**PATH C:\OSPanel\domains\localhost\Desyatnikova\lab4\resources\views/Main.blade.php ENDPATH**/ ?>